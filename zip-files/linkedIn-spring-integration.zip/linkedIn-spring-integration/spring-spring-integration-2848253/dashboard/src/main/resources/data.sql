INSERT INTO DEVICE (name, display) VALUES
  ('solar_1', 'House Solar'),
  ('solar_2', 'Office Solar'),
  ('store_1', 'Main Battery');