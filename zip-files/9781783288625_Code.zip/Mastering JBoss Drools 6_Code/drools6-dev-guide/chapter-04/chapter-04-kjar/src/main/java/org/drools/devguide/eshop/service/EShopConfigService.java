package org.drools.devguide.eshop.service;

public interface EShopConfigService {

    boolean isMidHighCategoryEnabled();
}
