# OozinozDpij
Code examples from "Design Patterns in Java" book by Steve Metsker and William Wake


Source: http://xp123.com/oozinoz/designpatternsinjava.htm


Copyright (c) 2001, 2005. Steven J. Metsker. Steve Metsker makes no representations
or warranties about the fitness of this software for any particular purpose, including 
the implied warranty of merchantability. Please use this software as you wish with the
sole restriction that you may not claim that you wrote it.
