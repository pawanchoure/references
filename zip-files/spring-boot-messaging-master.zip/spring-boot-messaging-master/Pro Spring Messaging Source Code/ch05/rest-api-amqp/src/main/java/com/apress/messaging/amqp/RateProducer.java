package com.apress.messaging.amqp;

public class RateProducer {

}
