package com.apress.messaging.domain;

public class Invoice {

	private Float total;

	public Float getTotal() {
		return total;
	}

	public void setTotal(Float total) {
		this.total = total;
	}

}
