package com.apress.messaging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudStreamSourceDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudStreamSourceDemoApplication.class, args);
	}
}
