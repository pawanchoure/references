package com.apress.messaging;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudStreamProcessorDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudStreamProcessorDemoApplication.class, args);
	}
}
