package com.apress.messaging.controller;

public class SimpleController {

	
}
