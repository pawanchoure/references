package com.pluralsight.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobomanticsBillingApplication {

    public static void main(String[] args) {
        SpringApplication.run(GlobomanticsBillingApplication.class, args);
    }
}
