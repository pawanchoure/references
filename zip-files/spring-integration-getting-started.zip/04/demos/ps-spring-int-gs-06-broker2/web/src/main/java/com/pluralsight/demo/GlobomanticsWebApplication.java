package com.pluralsight.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobomanticsWebApplication {

    public static void main(String[] args) {
        SpringApplication.run(GlobomanticsWebApplication.class, args);
    }
}
