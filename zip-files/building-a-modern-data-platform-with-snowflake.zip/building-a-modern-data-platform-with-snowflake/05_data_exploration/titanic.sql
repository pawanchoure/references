-- Check out surviving passenger list

select
    *
from
    analytics.titanic.passengers_survived
limit 50;


-- Check out age buckets
select
    *
from
    analytics.titanic.age_buckets;
