# Building a Modern Data Platform with Snowflake

Supplementary material for Pearson's [Building a Modern Data Platform with Snowflake](https://learning.oreilly.com/live-training/courses/building-a-modern-data-platform-with-snowflake/0636920414964/).


## What we'll be building

![Warehouse](warehouse.png)
