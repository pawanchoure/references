package com.ubs.derivs.coding.assignment.main;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import com.ubs.derivs.coding.assignment.publisher.EventGenerator;
import com.ubs.derivs.coding.assignment.subscriber.Subscriber;
import com.ubs.derivs.coding.assignment.notification.NotificationManager;
import com.ubs.derivs.coding.assignment.subscriber.SubscriberImpl;

final class RandomizedSubscriptionRunner {

    private final NotificationManager notificationManager;
    private final EventGenerator eventGenerator;

    RandomizedSubscriptionRunner(
        final NotificationManager notificationManager, final EventGenerator eventGenerator) {
        this.notificationManager = notificationManager;
        this.eventGenerator = eventGenerator;
    }

    void run() {
        final Random random = new Random();
        final List<Subscriber> subscribers = new ArrayList<>();
        int runtime = 0;
        try {
            do {
                //Subscribe
                if (random.nextBoolean()) {

                    final String topic = eventGenerator.randomTopic();
                    final SubscriberImpl subscriber = new SubscriberImpl(subscribers.size() + 1);
                    System.out.println("Subscriber: Adding subscriber "+subscriber);
                    subscribers.add(subscriber);
                    notificationManager.registerSubscriber(topic, subscriber);
                }
                //Unsubscribe somebody if there any subscribers
                if (!subscribers.isEmpty() && random.nextBoolean()) {
                    final int randomIndexToRemove = random.nextInt(subscribers.size());
                    final Subscriber subscriber = subscribers.remove(randomIndexToRemove);
                    System.out.println("Subscriber: Removing subscriber "+subscriber);
                    notificationManager.unRegisterSubscriber(subscriber);
                }

                //500-1500 millis delay
                int delay = random.nextInt(1500 - 500) + 500;
                runtime += delay;
                System.out.println("Subscriber: total runtime {" + runtime + "},  waiting time {" + delay + "}");
                Thread.sleep(delay);
            } while (runtime < MainLauncher.TOTAL_RUN_TIME_MS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
