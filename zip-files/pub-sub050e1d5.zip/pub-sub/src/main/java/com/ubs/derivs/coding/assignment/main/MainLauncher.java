package com.ubs.derivs.coding.assignment.main;

import com.ubs.derivs.coding.assignment.notification.NotificationManager;
import com.ubs.derivs.coding.assignment.notification.NotificationManagerImpl;
import com.ubs.derivs.coding.assignment.publisher.EventGenerator;

public final class MainLauncher {

    public static final int TOTAL_RUN_TIME_MS = 10000;

    public static void main(String[] args) throws InterruptedException {
        final NotificationManager notificationManager = new NotificationManagerImpl();

        //Event Generation
        final EventGenerator eventGenerator = new EventGenerator(notificationManager);
        final Thread generatorThread = new Thread(eventGenerator::generateEvents);

        //Subscribe and unsubscribe subscribers
        final RandomizedSubscriptionRunner randomizedSubscriptionRunner1 =
            new RandomizedSubscriptionRunner(notificationManager, eventGenerator);
        final RandomizedSubscriptionRunner randomizedSubscriptionRunner2 =
            new RandomizedSubscriptionRunner(notificationManager, eventGenerator);
        final Thread subscriptionRunnerThread1 = new Thread(randomizedSubscriptionRunner1::run);
        final Thread subscriptionRunnerThread2 = new Thread(randomizedSubscriptionRunner2::run);

        //Start the threads
        generatorThread.start();
        subscriptionRunnerThread1.start();
        subscriptionRunnerThread2.start();
        //Wait until all events are through
        generatorThread.join();
        subscriptionRunnerThread1.join();
        subscriptionRunnerThread2.join();
    }

}
