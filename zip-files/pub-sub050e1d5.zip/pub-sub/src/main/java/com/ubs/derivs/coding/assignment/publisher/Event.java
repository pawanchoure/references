package com.ubs.derivs.coding.assignment.publisher;

import java.util.Objects;

public class Event {

    private final String topic;
    private final int event;
    private final String eventName;

    Event(final String topic, final int event, final String eventName) {
        this.topic = topic;
        this.event = event;
        this.eventName = eventName;
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Event event1 = (Event) o;
        return event == event1.event &&
            Objects.equals(topic, event1.topic) &&
            Objects.equals(eventName, event1.eventName);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topic, event, eventName);
    }

    @Override
    public String toString() {
        return "Event{" +
            "topic='" + topic + '\'' +
            ", event=" + event +
            ", eventName='" + eventName + '\'' +
            '}';
    }
}
