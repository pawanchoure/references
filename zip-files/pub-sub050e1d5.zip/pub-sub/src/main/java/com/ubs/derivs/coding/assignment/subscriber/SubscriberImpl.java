package com.ubs.derivs.coding.assignment.subscriber;

import com.ubs.derivs.coding.assignment.publisher.Event;

public class SubscriberImpl implements Subscriber {

    private final int name;

    public SubscriberImpl(final int name) {
        this.name = name;
    }

    @Override
    public void processEvent(Event e) {
        try {
            System.out.println("Subscriber " + name + ": Processing event " + e);
            //This is just a proxy for timetaken to process the event.
            Thread.sleep(250);
            System.out.println("Subscriber " + name + ": Finished processing event " + e);
        } catch (InterruptedException e1) {
            e1.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "SubscriberImpl{" +
                "name=" + name +
                '}';
    }
}
