package com.ubs.derivs.coding.assignment.notification;

import com.ubs.derivs.coding.assignment.publisher.Event;
import com.ubs.derivs.coding.assignment.subscriber.Subscriber;


public interface NotificationManager {

    void registerSubscriber(String topic, Subscriber subscriber);

    void unRegisterSubscriber(Subscriber subscriber);

    void notifySubscribers(String topic, Event event);

}
