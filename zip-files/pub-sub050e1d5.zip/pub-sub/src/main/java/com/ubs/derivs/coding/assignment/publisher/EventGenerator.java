package com.ubs.derivs.coding.assignment.publisher;

import java.util.HashMap;
import java.util.Map;
import java.util.Random;

import com.ubs.derivs.coding.assignment.main.MainLauncher;
import com.ubs.derivs.coding.assignment.notification.NotificationManager;

public class EventGenerator {

    private static final String TOPIC = "TOPIC";
    private static final String EVENT = "EVENT";
    private final NotificationManager notificationMgr;
    private final Map<Integer, String> topics;
    private final Random random;

    public EventGenerator(final NotificationManager notificationMgr) {
        this.notificationMgr = notificationMgr;
        this.random = new Random();
        this.topics = new HashMap<>();
        this.topics.put(0, TOPIC + 0);
        this.topics.put(1, TOPIC + 1);
        this.topics.put(2, TOPIC + 2);
        this.topics.put(3, TOPIC + 3);
        this.topics.put(4, TOPIC + 4);
    }

    public String randomTopic() {
        return topics.get(random.nextInt(5));
    }

    public void generateEvents() {
        int runtime = 0;
        try {
            do {
                //Select a random topic, create event and send it to the notification manager
                final String topic = randomTopic();
                Event event = new Event(topic, runtime, EVENT + runtime);
                System.out.println("EventGenerator: notifying with event "+event);
                notificationMgr.notifySubscribers(topic, event);

                // 100-300 delay
                int delay = random.nextInt(300 - 100) + 100;
                runtime += delay;
                System.out.println("EventGenerator: total runtime {" + runtime + "} waiting for {" + delay + "}");
                Thread.sleep(delay);
            } while (runtime < MainLauncher.TOTAL_RUN_TIME_MS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}
