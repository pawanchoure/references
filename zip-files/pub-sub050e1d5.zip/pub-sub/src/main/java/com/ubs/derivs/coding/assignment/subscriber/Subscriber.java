package com.ubs.derivs.coding.assignment.subscriber;

import com.ubs.derivs.coding.assignment.publisher.Event;

public interface Subscriber {

    public void processEvent(Event e);
}
