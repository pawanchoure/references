package com.ubs.derivs.coding.assignment.notification;

import java.util.ArrayList;
import java.util.List;

import com.ubs.derivs.coding.assignment.publisher.Event;
import com.ubs.derivs.coding.assignment.subscriber.Subscriber;

/**
 * 1) Make sure subscribers receive notifications according to the topic they subscribe.
 * 2) Make this class thread safe and concurrency friendly.
 * 3) Ensure the time taken (by a subscriber) to process an event does NOT delay the notification to other subscribers.
 * 4) Bonus: Provide proof that your solution works.
 * <p>
 * <p>
 * Example run Log:
 * <p>
 * Subscriber: total runtime {1272},  waiting time {1272}
 * EventGenerator: notifying with event Event{topic='TOPIC2', event=0, eventName='EVENT0'}
 * EventGenerator: total runtime {217} waiting for {217}
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {782},  waiting time {782}
 * EventGenerator: notifying with event Event{topic='TOPIC2', event=217, eventName='EVENT217'}
 * EventGenerator: total runtime {330} waiting for {113}
 * EventGenerator: notifying with event Event{topic='TOPIC4', event=330, eventName='EVENT330'}
 * EventGenerator: total runtime {525} waiting for {195}
 * EventGenerator: notifying with event Event{topic='TOPIC1', event=525, eventName='EVENT525'}
 * EventGenerator: total runtime {815} waiting for {290}
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {1288},  waiting time {506}
 * EventGenerator: notifying with event Event{topic='TOPIC2', event=815, eventName='EVENT815'}
 * Subscriber 1: Processing event Event{topic='TOPIC2', event=815, eventName='EVENT815'}
 * Subscriber 1: Finished processing event Event{topic='TOPIC2', event=815, eventName='EVENT815'}
 * EventGenerator: total runtime {979} waiting for {164}
 * EventGenerator: notifying with event Event{topic='TOPIC3', event=979, eventName='EVENT979'}
 * Subscriber 1: Processing event Event{topic='TOPIC3', event=979, eventName='EVENT979'}
 * Subscriber: total runtime {2368},  waiting time {1096}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {2198},  waiting time {910}
 * Subscriber 1: Finished processing event Event{topic='TOPIC3', event=979, eventName='EVENT979'}
 * Exception in thread "Thread-0" java.util.ConcurrentModificationException
 * 	at java.util.ArrayList$Itr.checkForComodification(ArrayList.java:901)
 * 	at java.util.ArrayList$Itr.next(ArrayList.java:851)
 * 	at com.ubs.derivs.coding.assignment.notification.NotificationManagerImpl.notifySubscribers(NotificationManagerImpl.java:72)
 * 	at com.ubs.derivs.coding.assignment.publisher.EventGenerator.generateEvents(EventGenerator.java:41)
 * 	at com.ubs.derivs.coding.assignment.main.MainLauncher$$Lambda$1/2003749087.run(Unknown Source)
 * 	at java.lang.Thread.run(Thread.java:745)
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {3674},  waiting time {1476}
 * Subscriber: total runtime {3189},  waiting time {821}
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {4054},  waiting time {865}
 * Subscriber: total runtime {4239},  waiting time {565}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {4849},  waiting time {795}
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {5634},  waiting time {1395}
 * Subscriber: Adding subscriber SubscriberImpl{name=1}
 * Subscriber: Removing subscriber SubscriberImpl{name=1}
 * Subscriber: total runtime {5498},  waiting time {649}
 *
 */
public class NotificationManagerImpl implements NotificationManager {

    private final List<Subscriber> list = new ArrayList<>();

    @Override
    public void registerSubscriber(final String topic, final Subscriber subscriber) {
        list.add(subscriber);
    }

    @Override
    public void unRegisterSubscriber(final Subscriber subscriber) {
        list.remove(subscriber);
    }

    @Override
    public void notifySubscribers(final String topic, final Event event) {
        for (Subscriber subscriber : list) {
            subscriber.processEvent(event);
        }
    }
}
