package com.apress.prospring4.ch14;

public interface RuleFactory {
    Rule getAgeCategoryRule();
}
