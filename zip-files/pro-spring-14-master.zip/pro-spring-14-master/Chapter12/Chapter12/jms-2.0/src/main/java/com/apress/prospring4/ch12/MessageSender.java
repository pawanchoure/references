package com.apress.prospring4.ch12;

public interface MessageSender {
    void sendMessage(String message);
}
