insert into car (license_plate, manufacturer, manufacture_date) values ('LICENSE-1001', 'Ford', '1980-07-30');
insert into car (license_plate, manufacturer, manufacture_date) values ('LICENSE-1002', 'Toyota', '1992-12-30');
insert into car (license_plate, manufacturer, manufacture_date) values ('LICENSE-1003', 'BMW', '2003-1-6');
