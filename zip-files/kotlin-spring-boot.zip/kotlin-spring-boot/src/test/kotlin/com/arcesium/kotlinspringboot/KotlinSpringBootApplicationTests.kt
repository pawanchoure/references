package com.arcesium.kotlinspringboot

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class KotlinSpringBootApplicationTests {

	@Test
	fun contextLoads() {
	}

}
