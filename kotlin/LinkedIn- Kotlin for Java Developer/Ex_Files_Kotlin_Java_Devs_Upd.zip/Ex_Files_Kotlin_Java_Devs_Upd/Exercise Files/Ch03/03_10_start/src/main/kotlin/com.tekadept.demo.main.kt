// 03_10 Fizz Buzz Challenge start

fun main(args: Array<String>) {
    println("Fizz Buzz")
}
