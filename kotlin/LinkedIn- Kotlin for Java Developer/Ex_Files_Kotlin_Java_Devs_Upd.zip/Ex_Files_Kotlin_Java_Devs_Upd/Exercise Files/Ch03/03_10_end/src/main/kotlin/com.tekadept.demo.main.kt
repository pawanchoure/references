// 03_10 Fizz Buzz Challenge end

fun main(args: Array<String>) {
    println("Fizz Buzz")
}
